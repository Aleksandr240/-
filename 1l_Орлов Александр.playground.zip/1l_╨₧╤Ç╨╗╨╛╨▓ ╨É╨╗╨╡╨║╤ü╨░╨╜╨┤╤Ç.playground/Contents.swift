import UIKit

var greeting = "Hello, playground"
// Первое задание "Решение квадратного уравнения"
let a:Double = 4 // Даем значение а
let b:Double = 8 // Даем значение b
let c:Double = -3 // Даем значение c
var x1: Double = 0 // Даем значение Х1
var x2: Double = 0 // Даем значение Х2
var d: Double = b * b - 4 * a * c
if (d > 0) {
d = sqrt(d)
x1 = (-b - d) / (2 * a)
x2 = (-b + d) / (2 * a)
 print("Первый корень" + String(x1), "Второй корень " + String(x2))
}
else if (d == 0) {
x1 = -b / (2 * a)
print(x1)
}
else if (d < 0) {
print("Корень не существует") // Выводим принт в случае если Корень не существует
}









// Задание 2
 
let cathetA = 6 //  Даем значение 1 катету
let cathetB = 11 // Даем  значение 2 катету
let S = (cathetA * cathetB ) // Задаем формулу для Площади
let P = (2 * S) // Задаем формулу для Периметра
let hipotenuse = (cathetA * 2 + cathetB * 2) // Задаем формулу для Гипотенузы
 print("Мы получили следующие результаты Площадь = \(S) , Периметр = \(P) , Гипотенуза = \(hipotenuse) ")












// Задание 3
let summ : Double = 150000
let procent : Double = 17.6
let years : Double = 5
var vklad : Double = summ * pow(1 + (procent/100), years)
print("Ваш вклад через \(years) лет составит \(vklad) рублей ")









